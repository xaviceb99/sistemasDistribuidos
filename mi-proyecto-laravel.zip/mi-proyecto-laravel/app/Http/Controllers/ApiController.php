<?php

namespace App\Http\Controllers;

use App\Models\Urls;
use Illuminate\Http\Request;

class ApiController extends Controller
{
    public function recibir(Request $request)
    {
        $url = Urls::get();
        return $url;
    }

    public function guardar_antigua(Request $request)
    {
        $url = Urls::create([
            'url'=> $request->url,
            'urlAcortada' => 'Doritos'
        ]);

        return $url;
    }

    public function guardar(Request $request)
    {

        $originalUrl = $request->url;
        // Check if the URL already exists
        $shortUrl = Urls::where('url', $originalUrl)->first();

        if (!$shortUrl) {
            $shortCode = $this->generateShortCode();
            $shortUrl = Urls::create([
                'url' => $originalUrl,
                'urlAcortada' => $shortCode
            ]);
        }

        return response()->json([$shortUrl->url, $shortUrl->urlAcortada]);
    }

    public function redirectToOriginal($shortCode)
    {
        $shortUrl = ShortUrl::where('short_code', $shortCode)->firstOrFail();

        return redirect($shortUrl->original_url);
    }

    private function generateShortCode()
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $shortCode = '';
        for ($i = 0; $i < 6; $i++) {
            $shortCode .= $characters[rand(0, $charactersLength - 1)];
        }

        // Ensure the generated code is unique
        while (Urls::where('urlAcortada', $shortCode)->exists()) {
            $shortCode = '';
            for ($i = 0; $i < 6; $i++) {
                $shortCode .= $characters[rand(0, $charactersLength - 1)];
            }
        }

        return $shortCode;
    }
}


