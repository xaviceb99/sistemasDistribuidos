<?php

namespace App\Http\Controllers;

use App\Services\UrlShortenerService;
use Illuminate\Http\Request;

class UrlController extends Controller
{
    protected $urlShortener;

    public function __construct(UrlShortenerService $urlShortener)
    {
        $this->urlShortener = $urlShortener;
    }

    public function shorten(Request $request)
    {
        $request->validate([
            'url' => 'required|url',
        ]);

        $shortUrl = $this->urlShortener->shortenUrl($request->input('url'));

        if ($shortUrl) {
            return response()->json(['short_url' => $shortUrl], 200);
        } else {
            return response()->json(['error' => 'Unable to shorten URL'], 500);
        }
    }
}
