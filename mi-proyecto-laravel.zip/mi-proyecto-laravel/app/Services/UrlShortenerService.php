<?php

namespace App\Services;

use GuzzleHttp\Client;

class UrlShortenerService
{
    protected $client;
    protected $apiUrl = 'https://api.tinyurl.com/create';

    public function __construct()
    {
        $this->client = new Client();
    }

    public function shortenUrl($longUrl)
    {
        $response = $this->client->post($this->apiUrl, [
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . env('yENxqZneZpkLRr0oADwQ9TSAghDT7Hbyr28PUm5LIpDavHNByHeKTFqQu1Up'),
            ],
            'json' => [
                'url' => $longUrl,
            ],
        ]);

        $data = json_decode($response->getBody(), true);

        return $data['data']['tiny_url'] ?? null;
    }
}
